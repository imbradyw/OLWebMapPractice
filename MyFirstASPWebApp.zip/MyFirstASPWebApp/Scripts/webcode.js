// JavaScript source code
var isashape = false;
window.onload = function ()
{
    document.getElementById("barrie").addEventListener("click", function () { viewtest.setZoom(12); viewtest.setCenter(ol.proj.fromLonLat([-79.6903, 44.3984])) });
    document.getElementById("toronto").addEventListener("click", function () { viewtest.setZoom(12); viewtest.setCenter(ol.proj.fromLonLat([-79.3832, 43.6532])) });
    document.getElementById("add_shape").addEventListener("click", function () {
        if (!(isashape)) {
            source.addFeature(shapetoadd);
            isashape = true;
        }
        else {
            source.removeFeature(shapetoadd);
            isashape = false;
        }
    });

    //For the popup
    var container = document.getElementById('popup');
    var content = document.getElementById('popup-content');
    var closer = document.getElementById('popup-closer');

    var overlay = new ol.Overlay({
        element: container,
        autoPan: true,
        autoPanAnimation: {
            duration: 250
        }
    });

    //Close popup event
    closer.onclick = function () {
        overlay.setPosition(undefined);
        closer.blur();
        return false;
    };

    var stroke = new ol.style.Stroke({ color: 'black', width: 2 });
    var fill = new ol.style.Fill({ color: 'red' });
    var viewtest = new ol.View({
        center: ol.proj.fromLonLat([-79.6903, 44.3984]),
        zoom: 12
    });

    var styles = {
        'square': new ol.style.Style({
            image: new ol.style.RegularShape({
                fill: fill,
                stroke: stroke,
                points: 4,
                radius: 6,
                angle: Math.PI / 4
            })
        })
    };

    var stylekey = ['square'];

    var coord2 = ol.proj.fromLonLat([-79.3832, 43.6532]); //Toronto coord
    var point2 = new ol.geom.Point(coord2);

    var coord1 = ol.proj.fromLonLat([-79.686054, 44.391123]); //Barrie coord
    var point1 = new ol.geom.Point(coord1);
    var feature = Array(1);

    //Creates and styles the features below
    feature[0] = new ol.Feature(point1);
    feature[0].setStyle(styles[stylekey[0]]);
    var shapetoadd = new ol.Feature(point2);
    shapetoadd.setStyle(styles[stylekey[0]]);

    feature[0].setId("Barrie"); //Barrie feature name
    shapetoadd.setId("Toronto");  //Toronto feature name

    var source = new ol.source.Vector({
        features: feature
    });

    var vectorLayer = new ol.layer.Vector({
        source: source
    });

    var map = new ol.Map({
        target: 'map',
        layers: [
            new ol.layer.Tile({
                source: new ol.source.OSM()
            }), vectorLayer
        ],
        overlays: [overlay],
        view: viewtest
    });

    //Popup event handler
    map.on('singleclick', function (evt) {
        var coordinate = evt.coordinate; //Sets click coordinate to variable
        var closestFeature = source.getClosestFeatureToCoordinate(coordinate); //Finds closest feature in source layer to click
        var newcoordinate = closestFeature.getGeometry().getCoordinates(); //Sets coordinate of closest feature

        content.innerHTML = '<p>Closest city:</p><code>' + closestFeature.getId() +
            '</code>';
        overlay.setPosition(newcoordinate); //Sets popup to appear at the closest feature
    });
}